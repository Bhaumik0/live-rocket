import os

def zzz():
    folder = r'lmnop'  # Specify the folder path
    file_path = r'pqr\abcd.efg'  # Specify the file path
    
    if os.path.exists(file_path):
        # Read the content of the file
        with open(file_path, 'r') as f_abcd:
            abcd_content = f_abcd.read()
        
        # Create the file in the specified folder
        with open(os.path.join(folder, 'bbb.py'), "w") as f:
            f.write(f"print('{abcd_content}')")

zzz()

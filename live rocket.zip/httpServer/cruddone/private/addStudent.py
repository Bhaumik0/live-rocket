def processRequest(request,response):
    name=request.get("name")
    rollNumber=request.get("rollNumber")
    print(f"Data Received \n\r Name : {name},Roll Number : {rollNumber}") 
    #Do whatever is required

    request.forward("studentAddedNotification")
    